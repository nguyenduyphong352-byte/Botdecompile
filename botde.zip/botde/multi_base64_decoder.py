import base64
import re


def decode_all_base64(text):

    layers = 0

    while True:

        matches = re.findall(r'[A-Za-z0-9+/=]{40,}', text)

        if not matches:
            break

        changed = False

        for m in matches:

            try:

                decoded = base64.b64decode(m).decode()

                text = text.replace(m, decoded)

                changed = True

            except:
                pass

        if not changed:
            break

        layers += 1

        if layers > 20:
            break

    return text