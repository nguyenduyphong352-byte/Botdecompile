import os
import marshal
import tempfile
import subprocess


def decompile_pyc(data):

    try:

        # bỏ header pyc (16 bytes python 3.7+)
        header_size = 16
        code_obj = marshal.loads(data[header_size:])

        # lưu tạm file pyc
        temp_dir = tempfile.mkdtemp()

        pyc_path = os.path.join(temp_dir, "temp.pyc")

        with open(pyc_path, "wb") as f:
            f.write(data)

        output_file = os.path.join(temp_dir, "decompiled.py")

        # thử dùng uncompyle6
        try:

            subprocess.run(
                [
                    "uncompyle6",
                    "-o",
                    temp_dir,
                    pyc_path
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            out = os.path.join(temp_dir, "temp.py")

            if os.path.exists(out):
                with open(out, "rb") as f:
                    return f.read()

        except:
            pass

        # fallback sang decompyle3
        try:

            subprocess.run(
                [
                    "decompyle3",
                    "-o",
                    temp_dir,
                    pyc_path
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            out = os.path.join(temp_dir, "temp.py")

            if os.path.exists(out):
                with open(out, "rb") as f:
                    return f.read()

        except:
            pass

        # fallback cuối cùng: disassemble bytecode
        import dis

        dis_code = dis.Bytecode(code_obj).dis()

        return dis_code.encode()

    except Exception as e:

        print("[PYC] error:", e)

        return data