import ast


class JunkCodeRemover(ast.NodeTransformer):

    def visit_If(self, node):

        node = self.generic_visit(node)

        # if False:
        if isinstance(node.test, ast.Constant):

            if node.test.value is False:
                return None

            if node.test.value is True:
                return node.body

        return node


    def visit_While(self, node):

        node = self.generic_visit(node)

        if isinstance(node.test, ast.Constant):

            if node.test.value is False:
                return None

        return node


    def visit_Pass(self, node):

        return None


    def visit_Assign(self, node):

        node = self.generic_visit(node)

        # remove large useless integer
        if isinstance(node.value, ast.Constant):

            if isinstance(node.value.value, int):

                if len(str(node.value.value)) > 15:
                    return None

        # remove long random string
        if isinstance(node.value, ast.Constant):

            if isinstance(node.value.value, str):

                if len(node.value.value) > 200:
                    return None

        return node


def remove_junk(source_code: str):

    try:

        tree = ast.parse(source_code)

        cleaner = JunkCodeRemover()

        new_tree = cleaner.visit(tree)

        ast.fix_missing_locations(new_tree)

        return ast.unparse(new_tree)

    except Exception as e:

        print("[JunkRemover] Error:", e)

        return source_code