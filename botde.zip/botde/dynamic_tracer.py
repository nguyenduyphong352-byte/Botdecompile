import builtins

dumped_codes = []


def exec_hook(code, globals=None, locals=None):

    try:

        if isinstance(code, str):

            dumped_codes.append(code)

            with open("runtime_dumps/runtime_dump.py", "w", encoding="utf8") as f:
                f.write(code)

    except:
        pass

    return original_exec(code, globals, locals)


def enable_tracing():

    global original_exec

    original_exec = builtins.exec

    builtins.exec = exec_hook