import sys
import subprocess
import importlib
import os


# =============================
# AUTO INSTALL DEPENDENCIES
# =============================

required_packages = {
    "python-telegram-bot": "telegram",
    "uncompyle6": "uncompyle6",
    "capstone": "capstone"
}


def install(package):
    print(f"[SETUP] Installing {package}...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])


def ensure_packages():

    for package, module in required_packages.items():

        try:
            importlib.import_module(module)

        except ImportError:
            install(package)


ensure_packages()


# =============================
# IMPORT AFTER INSTALL
# =============================

from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters, ContextTypes

from engine import DeobfuscationEngine


# =============================
# CONFIG
# =============================

BOT_TOKEN = "8693841080:AAEIT3S0g0qWJpCPayOLFM3X8r7w-VL-N5I"

INPUT_DIR = "inputs"
OUTPUT_DIR = "outputs"

os.makedirs(INPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)


engine = DeobfuscationEngine()


# =============================
# BOT HANDLER
# =============================

async def handle_file(update: Update, context: ContextTypes.DEFAULT_TYPE):

    file = update.message.document

    if not file:
        await update.message.reply_text("Send python file (.py/.pyc/.exe)")
        return

    file_name = file.file_name
    file_path = os.path.join(INPUT_DIR, file_name)

    telegram_file = await file.get_file()
    await telegram_file.download_to_drive(file_path)

    await update.message.reply_text("File received. Processing...")

    try:

        result = engine.process_file(file_path)

        output_file = os.path.join(
            OUTPUT_DIR,
            "decompiled_" + file_name + ".py"
        )

        with open(output_file, "wb") as f:
            f.write(result)

        await update.message.reply_document(document=open(output_file, "rb"))

    except Exception as e:

        await update.message.reply_text(f"Error: {str(e)}")


# =============================
# MAIN
# =============================

def main():

    print("[BOT] Starting bot...")

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(
        MessageHandler(filters.Document.ALL, handle_file)
    )

    print("[BOT] Bot running...")

    app.run_polling()


if __name__ == "__main__":
    main()