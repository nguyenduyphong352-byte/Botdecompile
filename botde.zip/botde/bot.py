import os
import telebot

from engine import process_file


# =========================
# CONFIG
# =========================

BOT_TOKEN = "8693841080:AAEIT3S0g0qWJpCPayOLFM3X8r7w-VL-N5I"

DOWNLOAD_DIR = "downloads"


# =========================
# INIT
# =========================

bot = telebot.TeleBot(BOT_TOKEN)

if not os.path.exists(DOWNLOAD_DIR):
    os.makedirs(DOWNLOAD_DIR)


# =========================
# START COMMAND
# =========================

@bot.message_handler(commands=['start'])
def start(message):

    bot.reply_to(
        message,
        "🤖 Python Deobfuscator Bot\n\n"
        "Gửi file Python bị mã hoá (.py / .txt / .pyc)\n"
        "Bot sẽ cố gắng gỡ obfuscation và trả lại source."
    )


# =========================
# FILE HANDLER
# =========================

@bot.message_handler(content_types=['document'])
def handle_file(message):

    try:

        file_info = bot.get_file(message.document.file_id)

        downloaded_file = bot.download_file(file_info.file_path)

        filename = message.document.file_name

        save_path = os.path.join(DOWNLOAD_DIR, filename)

        with open(save_path, "wb") as f:
            f.write(downloaded_file)

        bot.reply_to(message, "📥 File nhận được. Đang xử lý...")

        # run engine
        result_path = process_file(save_path)

        bot.send_document(
            message.chat.id,
            open(result_path, "rb"),
            caption="✅ File đã được xử lý"
        )

    except Exception as e:

        bot.reply_to(message, f"❌ Lỗi xử lý:\n{e}")


# =========================
# RUN BOT
# =========================

print("[BOT] Bot running...")

bot.infinity_polling()