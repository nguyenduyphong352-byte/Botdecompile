import base64
import binascii
import zlib
import gzip
import bz2
import lzma
import marshal


def detect_layer(data):

    # Detect PYC file
    if len(data) > 4:
        magic = data[:4]
        if magic in [
            b'\x42\x0d\x0d\x0a',
            b'\x0a\x0d\x0d\x42'
        ]:
            return "pyc"

    # Detect plain python
    try:
        text = data.decode()

        if "import " in text or "def " in text or "class " in text:
            return "plain_python"

        if "exec(" in text:
            return "exec_wrapper"

    except:
        pass

    # Detect base64
    try:
        decoded = base64.b64decode(data, validate=True)
        if decoded:
            return "base64"
    except:
        pass

    # Detect base85
    try:
        decoded = base64.b85decode(data)
        if decoded:
            return "base85"
    except:
        pass

    # Detect hex encoding
    try:
        decoded = binascii.unhexlify(data.strip())
        if decoded:
            return "hex"
    except:
        pass

    # Detect zlib
    try:
        zlib.decompress(data)
        return "zlib"
    except:
        pass

    # Detect gzip
    try:
        gzip.decompress(data)
        return "gzip"
    except:
        pass

    # Detect bz2
    try:
        bz2.decompress(data)
        return "bz2"
    except:
        pass

    # Detect lzma
    try:
        lzma.decompress(data)
        return "lzma"
    except:
        pass

    # Detect marshal
    try:
        obj = marshal.loads(data)
        if obj:
            return "marshal"
    except:
        pass

    return "unknown"