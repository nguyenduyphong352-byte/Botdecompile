import subprocess
import tempfile
import os


def run_in_sandbox(file_path):

    temp_dir = tempfile.mkdtemp()

    try:

        result = subprocess.run(
            ["python", file_path],
            cwd=temp_dir,
            capture_output=True,
            timeout=10
        )

        stdout = result.stdout.decode(errors="ignore")

        stderr = result.stderr.decode(errors="ignore")

        return stdout + "\n" + stderr

    except Exception as e:

        return str(e)