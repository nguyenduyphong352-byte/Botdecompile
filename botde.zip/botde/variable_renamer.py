import ast
import keyword
import builtins
import string


class VariableRenamer(ast.NodeTransformer):

    def __init__(self):
        self.name_map = {}
        self.counter = 0

        self.reserved = set(keyword.kwlist)
        self.reserved.update(dir(builtins))

    def new_name(self):
        self.counter += 1
        return f"var_{self.counter}"

    def should_rename(self, name):

        if name in self.reserved:
            return False

        if name.startswith("__") and name.endswith("__"):
            return False

        # hex style variable
        if name.startswith("_0x"):
            return True

        # unicode variable
        try:
            name.encode("ascii")
        except:
            return True

        # random long name
        if len(name) > 12:
            return True

        return False

    def get_new_name(self, old):

        if old not in self.name_map:
            self.name_map[old] = self.new_name()

        return self.name_map[old]

    def visit_Name(self, node):

        if isinstance(node.ctx, (ast.Store, ast.Load, ast.Del)):

            if self.should_rename(node.id):

                new_name = self.get_new_name(node.id)
                node.id = new_name

        return node

    def visit_arg(self, node):

        if self.should_rename(node.arg):

            node.arg = self.get_new_name(node.arg)

        return node


def rename_variables(source_code: str):

    try:

        tree = ast.parse(source_code)

        renamer = VariableRenamer()

        new_tree = renamer.visit(tree)

        ast.fix_missing_locations(new_tree)

        return ast.unparse(new_tree)

    except Exception as e:

        print("[VariableRenamer] Error:", e)
        return source_code