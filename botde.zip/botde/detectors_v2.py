import base64
import binascii
import re
import zlib
import gzip
import bz2
import lzma


def is_plain_python(data):

    try:
        text = data.decode("utf-8")

        keywords = [
            "import",
            "def ",
            "class ",
            "print(",
            "if ",
            "for ",
            "while ",
        ]

        for k in keywords:
            if k in text:
                return True

    except:
        pass

    return False


def detect_base64(data):

    try:
        text = data.decode().strip()

        if len(text) % 4 != 0:
            return False

        base64.b64decode(text)

        return True

    except:
        return False


def detect_base85(data):

    try:
        text = data.decode()

        if re.match(r'^[0-9A-Za-z!#$%&()*+\-;<=>?@^_`{|}~]+$', text):
            base64.b85decode(text)
            return True

    except:
        pass

    return False


def detect_hex(data):

    try:
        text = data.decode()

        if re.fullmatch(r'[0-9a-fA-F]+', text):
            binascii.unhexlify(text)
            return True

    except:
        pass

    return False


def detect_zlib(data):

    try:
        zlib.decompress(data)
        return True
    except:
        return False


def detect_gzip(data):

    try:
        gzip.decompress(data)
        return True
    except:
        return False


def detect_bz2(data):

    try:
        bz2.decompress(data)
        return True
    except:
        return False


def detect_lzma(data):

    try:
        lzma.decompress(data)
        return True
    except:
        return False


def detect_marshal(data):

    try:
        import marshal

        marshal.loads(data)
        return True

    except:
        return False


def detect_pyc(data):

    if len(data) > 16:

        magic = data[:4]

        if magic in [
            b'\x42\x0d\x0d\x0a',
            b'\x16\x0d\x0d\x0a',
        ]:
            return True

    return False


def detect_exec_wrapper(data):

    try:

        text = data.decode()

        patterns = [
            "exec(",
            "eval(",
            "compile(",
        ]

        for p in patterns:
            if p in text:
                return True

    except:
        pass

    return False


def detect_layer(data):

    if detect_pyc(data):
        return "pyc"

    if detect_zlib(data):
        return "zlib"

    if detect_gzip(data):
        return "gzip"

    if detect_bz2(data):
        return "bz2"

    if detect_lzma(data):
        return "lzma"

    if detect_marshal(data):
        return "marshal"

    if detect_base64(data):
        return "base64"

    if detect_base85(data):
        return "base85"

    if detect_hex(data):
        return "hex"

    if detect_exec_wrapper(data):
        return "exec_wrapper"

    if is_plain_python(data):
        return "plain_python"

    return "unknown"