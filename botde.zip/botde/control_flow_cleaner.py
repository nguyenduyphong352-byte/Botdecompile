import ast


class ControlFlowCleaner(ast.NodeTransformer):

    def visit_If(self, node):

        node = self.generic_visit(node)

        if isinstance(node.test, ast.Constant):

            if node.test.value is True:
                return node.body

            if node.test.value is False:
                return node.orelse

        return node


    def visit_Try(self, node):

        node = self.generic_visit(node)

        if not node.handlers and not node.finalbody:

            return node.body

        return node


    def visit_While(self, node):

        node = self.generic_visit(node)

        if isinstance(node.test, ast.Constant):

            if node.test.value is False:
                return None

        return node


    def visit_For(self, node):

        node = self.generic_visit(node)

        if isinstance(node.iter, ast.List):

            if len(node.iter.elts) == 0:
                return None

        return node


def clean_control_flow(source_code: str):

    try:

        tree = ast.parse(source_code)

        cleaner = ControlFlowCleaner()

        new_tree = cleaner.visit(tree)

        ast.fix_missing_locations(new_tree)

        return ast.unparse(new_tree)

    except Exception as e:

        print("[ControlFlowCleaner] Error:", e)

        return source_code