import builtins
import marshal
import os
import types

DUMP_DIR = "runtime_dumps"

os.makedirs(DUMP_DIR, exist_ok=True)

dump_index = 0


def save_dump(data, ext="py"):

    global dump_index

    file_path = os.path.join(DUMP_DIR, f"dump_{dump_index}.{ext}")

    if isinstance(data, bytes):
        with open(file_path, "wb") as f:
            f.write(data)

    elif isinstance(data, str):
        with open(file_path, "w", encoding="utf-8", errors="ignore") as f:
            f.write(data)

    else:
        with open(file_path, "w") as f:
            f.write(str(data))

    print(f"[RUNTIME] dumped → {file_path}")

    dump_index += 1


# Hook exec
_original_exec = builtins.exec

def exec_hook(code, globals=None, locals=None):

    try:

        if isinstance(code, str):
            save_dump(code)

        elif isinstance(code, bytes):
            save_dump(code)

        elif isinstance(code, types.CodeType):

            import dis

            disassembled = dis.Bytecode(code).dis()

            save_dump(disassembled, "txt")

    except Exception as e:
        print("[RUNTIME] exec hook error:", e)

    return _original_exec(code, globals, locals)


# Hook eval
_original_eval = builtins.eval

def eval_hook(expression, globals=None, locals=None):

    try:

        if isinstance(expression, str):
            save_dump(expression)

    except:
        pass

    return _original_eval(expression, globals, locals)


# Hook compile
_original_compile = builtins.compile

def compile_hook(source, filename, mode, flags=0, dont_inherit=False, optimize=-1):

    try:

        if isinstance(source, str):
            save_dump(source)

    except:
        pass

    return _original_compile(source, filename, mode, flags, dont_inherit, optimize)


# Hook marshal.loads
_original_marshal_loads = marshal.loads

def marshal_loads_hook(data):

    try:

        save_dump(data, "marshal")

    except:
        pass

    return _original_marshal_loads(data)


def enable_runtime_hooks():

    builtins.exec = exec_hook
    builtins.eval = eval_hook
    builtins.compile = compile_hook
    marshal.loads = marshal_loads_hook

    print("[RUNTIME] hooks enabled")