import ast


class StringDecryptor(ast.NodeTransformer):

    def visit_BinOp(self, node):

        node = self.generic_visit(node)

        if isinstance(node.op, ast.Add):

            left = node.left
            right = node.right

            if self.is_chr_call(left) and self.is_chr_call(right):

                try:

                    chars = []
                    self.collect_chr(node, chars)

                    return ast.Constant(value="".join(chars))

                except:
                    return node

        return node

    def is_chr_call(self, node):

        if not isinstance(node, ast.Call):
            return False

        if isinstance(node.func, ast.Name) and node.func.id == "chr":

            if len(node.args) == 1 and isinstance(node.args[0], ast.Constant):
                return True

        return False

    def collect_chr(self, node, chars):

        if isinstance(node, ast.Call):

            val = node.args[0].value
            chars.append(chr(val))

        elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):

            self.collect_chr(node.left, chars)
            self.collect_chr(node.right, chars)

    def visit_Call(self, node):

        node = self.generic_visit(node)

        # bytes([..]).decode()

        if isinstance(node.func, ast.Attribute):

            if node.func.attr == "decode":

                call = node.func.value

                if isinstance(call, ast.Call):

                    if isinstance(call.func, ast.Name) and call.func.id == "bytes":

                        try:

                            values = call.args[0].elts
                            string = "".join(chr(v.value) for v in values)

                            return ast.Constant(value=string)

                        except:
                            return node

        return node


def decrypt_strings(source_code: str):

    try:

        tree = ast.parse(source_code)

        transformer = StringDecryptor()

        new_tree = transformer.visit(tree)

        ast.fix_missing_locations(new_tree)

        return ast.unparse(new_tree)

    except Exception as e:

        print("[StringDecryptor] Error:", e)

        return source_code