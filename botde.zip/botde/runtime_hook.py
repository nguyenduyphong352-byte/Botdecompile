import builtins
import marshal
import os

# ==============================
# CONFIG
# ==============================

DUMP_DIR = "runtime_dumps"
MAX_DUMPS = 30

dump_count = 0
enabled = False

# original functions
_real_exec = builtins.exec
_real_eval = builtins.eval
_real_marshal_loads = marshal.loads


# ==============================
# UTILS
# ==============================

def ensure_dump_dir():
    if not os.path.exists(DUMP_DIR):
        os.makedirs(DUMP_DIR)


def save_dump(content, ext):

    global dump_count

    if dump_count >= MAX_DUMPS:
        return

    ensure_dump_dir()

    filename = f"{DUMP_DIR}/dump_{dump_count}.{ext}"

    try:
        if isinstance(content, bytes):
            with open(filename, "wb") as f:
                f.write(content)

        else:
            with open(filename, "w", encoding="utf-8", errors="ignore") as f:
                f.write(str(content))

        print(f"[RUNTIME] dumped → {filename}")

        dump_count += 1

    except Exception as e:
        print("[RUNTIME] dump error:", e)


# ==============================
# HOOKS
# ==============================

def hook_exec(code, globals=None, locals=None):

    if enabled:
        try:
            save_dump(code, "py")
        except:
            pass

    return _real_exec(code, globals, locals)


def hook_eval(code, globals=None, locals=None):

    if enabled:
        try:
            save_dump(code, "eval")
        except:
            pass

    return _real_eval(code, globals, locals)


def hook_marshal_loads(data):

    if enabled:
        try:
            save_dump(data, "marshal")
        except:
            pass

    return _real_marshal_loads(data)


# ==============================
# ENABLE / DISABLE
# ==============================

def enable_runtime_hook():

    global enabled

    if enabled:
        return

    print("[RUNTIME] Runtime hook enabled")

    builtins.exec = hook_exec
    builtins.eval = hook_eval
    marshal.loads = hook_marshal_loads

    enabled = True


def disable_runtime_hook():

    global enabled

    builtins.exec = _real_exec
    builtins.eval = _real_eval
    marshal.loads = _real_marshal_loads

    enabled = False

    print("[RUNTIME] Runtime hook disabled")