import ast
import dis
import types


def rebuild_from_code_object(code_obj):

    try:

        instructions = list(dis.get_instructions(code_obj))

        lines = []

        for instr in instructions:

            line = f"# {instr.opname} {instr.argrepr}"

            lines.append(line)

        return "\n".join(lines)

    except Exception as e:

        return f"# AST rebuild failed: {e}"


def rebuild_source(data):

    try:

        if isinstance(data, types.CodeType):

            return rebuild_from_code_object(data)

        text = data.decode(errors="ignore")

        try:

            tree = ast.parse(text)

            rebuilt = ast.unparse(tree)

            return rebuilt

        except:

            return text

    except:

        return str(data)