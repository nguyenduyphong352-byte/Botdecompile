import os
import zipfile
import subprocess
import tempfile

EXTRACT_DIR = "pyinstaller_extracted"

os.makedirs(EXTRACT_DIR, exist_ok=True)


def is_pyinstaller(file_path):

    try:
        with open(file_path, "rb") as f:
            data = f.read()

        if b"PYZ" in data or b"pyinstaller" in data.lower():
            return True

    except:
        pass

    return False


def extract_pyinstaller(file_path):

    print("[PYINSTALLER] Checking file")

    if not is_pyinstaller(file_path):
        print("[PYINSTALLER] Not a PyInstaller executable")
        return []

    print("[PYINSTALLER] PyInstaller detected")

    temp_dir = tempfile.mkdtemp()

    try:

        subprocess.run(
            [
                "pyinstxtractor.py",
                file_path
            ],
            cwd=temp_dir
        )

    except Exception as e:

        print("[PYINSTALLER] extractor error:", e)
        return []

    pyc_files = []

    for root, dirs, files in os.walk(temp_dir):

        for file in files:

            if file.endswith(".pyc"):

                pyc_files.append(os.path.join(root, file))

    print(f"[PYINSTALLER] found {len(pyc_files)} pyc files")

    return pyc_files