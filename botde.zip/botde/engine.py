import os
import base64
import zlib
import bz2
import lzma
import marshal

from runtime_hook import enable_runtime_hook


# =========================
# CONFIG
# =========================

OUTPUT_DIR = "output"
RUNTIME_DIR = "runtime_dumps"


# =========================
# UTIL
# =========================

def ensure_dirs():

    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    if not os.path.exists(RUNTIME_DIR):
        os.makedirs(RUNTIME_DIR)


def read_file(path):

    with open(path, "rb") as f:
        return f.read()


def write_file(path, data):

    with open(path, "wb") as f:
        f.write(data)


# =========================
# DETECT LAYERS
# =========================

def detect_base64(data):

    try:
        base64.b64decode(data)
        return True
    except:
        return False


def detect_zlib(data):

    try:
        zlib.decompress(data)
        return True
    except:
        return False


def detect_bz2(data):

    try:
        bz2.decompress(data)
        return True
    except:
        return False


def detect_lzma(data):

    try:
        lzma.decompress(data)
        return True
    except:
        return False


def detect_marshal(data):

    try:
        marshal.loads(data)
        return True
    except:
        return False


# =========================
# DECODE LAYER
# =========================

def decode_layers(data, max_layers=20):

    for i in range(max_layers):

        print(f"[ENGINE] scanning layer {i+1}")

        if detect_base64(data):

            print("[ENGINE] base64 detected")

            try:
                data = base64.b64decode(data)
                continue
            except:
                pass

        if detect_zlib(data):

            print("[ENGINE] zlib detected")

            try:
                data = zlib.decompress(data)
                continue
            except:
                pass

        if detect_bz2(data):

            print("[ENGINE] bz2 detected")

            try:
                data = bz2.decompress(data)
                continue
            except:
                pass

        if detect_lzma(data):

            print("[ENGINE] lzma detected")

            try:
                data = lzma.decompress(data)
                continue
            except:
                pass

        if detect_marshal(data):

            print("[ENGINE] marshal detected")

            try:
                code_obj = marshal.loads(data)

                source = f"exec({repr(code_obj)})"

                data = source.encode()

                continue
            except:
                pass

        break

    return data


# =========================
# RUNTIME UNPACK
# =========================

def runtime_unpack(source):

    print("[ENGINE] enabling runtime hook")

    enable_runtime_hook()

    try:

        exec(source, {})

    except Exception as e:

        print("[ENGINE] runtime execution stopped:", e)


# =========================
# FIND REAL SOURCE
# =========================

def find_real_source():

    files = os.listdir(RUNTIME_DIR)

    py_files = [f for f in files if f.endswith(".py")]

    if not py_files:
        return None

    py_files.sort()

    last = py_files[-1]

    return os.path.join(RUNTIME_DIR, last)


# =========================
# MAIN PIPELINE
# =========================

def process_file(input_path):

    ensure_dirs()

    print("[ENGINE] reading file")

    data = read_file(input_path)

    print("[ENGINE] decoding layers")

    data = decode_layers(data)

    try:
        source = data.decode(errors="ignore")
    except:
        source = str(data)

    print("[ENGINE] runtime unpack")

    runtime_unpack(source)

    print("[ENGINE] searching real source")

    real = find_real_source()

    if real:

        with open(real, "rb") as f:
            content = f.read()

        out_path = os.path.join(OUTPUT_DIR, "result.py")

        write_file(out_path, content)

        print("[ENGINE] real source saved:", out_path)

        return out_path

    else:

        out_path = os.path.join(OUTPUT_DIR, "decoded.py")

        write_file(out_path, source.encode())

        print("[ENGINE] decoded source saved:", out_path)

        return out_path