import os

from detectors_v2 import detect_layer
from decoders import decode_layer
from pyc_tools import decompile_pyc

from variable_renamer import rename_variables
from string_decryptor import decrypt_strings
from string_xor_decryptor import decrypt_xor_strings
from junk_code_remover import remove_junk
from control_flow_cleaner import clean_control_flow
from ast_beautifier import beautify_code

from runtime_dump import enable_runtime_hooks
from dynamic_tracer import enable_tracing


class DeobfuscationEngine:

    def __init__(self, max_layers=50):

        self.max_layers = max_layers

        # enable runtime tracing
        try:
            enable_runtime_hooks()
        except:
            pass

        try:
            enable_tracing()
        except:
            pass

    # ============================
    # READ FILE
    # ============================

    def read_file(self, path):

        with open(path, "rb") as f:
            return f.read()

    # ============================
    # DECODE LAYERS
    # ============================

    def decode_layers(self, data):

        for layer in range(self.max_layers):

            detected = detect_layer(data)

            print(f"[ENGINE] Layer {layer+1} detected:", detected)

            if detected == "plain_python":
                break

            elif detected == "base64":
                data = decode_layer("base64", data)

            elif detected == "base85":
                data = decode_layer("base85", data)

            elif detected == "hex":
                data = decode_layer("hex", data)

            elif detected == "zlib":
                data = decode_layer("zlib", data)

            elif detected == "gzip":
                data = decode_layer("gzip", data)

            elif detected == "bz2":
                data = decode_layer("bz2", data)

            elif detected == "lzma":
                data = decode_layer("lzma", data)

            elif detected == "marshal":
                data = decode_layer("marshal", data)

            elif detected == "exec_wrapper":
                data = decode_layer("exec_wrapper", data)

            elif detected == "pyc":
                data = decompile_pyc(data)

            else:
                print("[ENGINE] Unknown layer, stopping.")
                break

            if isinstance(data, str):
                data = data.encode()

        return data

    # ============================
    # CLEAN SOURCE CODE
    # ============================

    def clean_source(self, source):

        try:

            print("[ENGINE] Renaming variables...")
            source = rename_variables(source)

            print("[ENGINE] Decrypting strings...")
            source = decrypt_strings(source)

            print("[ENGINE] Decrypting XOR strings...")
            source = decrypt_xor_strings(source)

            print("[ENGINE] Removing junk code...")
            source = remove_junk(source)

            print("[ENGINE] Cleaning control flow...")
            source = clean_control_flow(source)

            print("[ENGINE] Beautifying code...")
            source = beautify_code(source)

        except Exception as e:

            print("[ENGINE] Cleaning error:", e)

        return source

    # ============================
    # MAIN PIPELINE
    # ============================

    def process_file(self, file_path):

        if not os.path.exists(file_path):
            raise Exception("File not found")

        print("[ENGINE] Processing:", file_path)

        data = self.read_file(file_path)

        # decode encoding layers
        data = self.decode_layers(data)

        # convert to source text
        try:
            source = data.decode("utf-8", errors="ignore")
        except:
            source = str(data)

        # clean source
        source = self.clean_source(source)

        return source.encode()