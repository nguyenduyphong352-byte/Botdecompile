import ast


class XORStringDecryptor(ast.NodeTransformer):

    def visit_BinOp(self, node):

        node = self.generic_visit(node)

        if isinstance(node.op, ast.BitXor):

            if isinstance(node.left, ast.Constant) and isinstance(node.right, ast.Constant):

                if isinstance(node.left.value, int) and isinstance(node.right.value, int):

                    try:

                        val = node.left.value ^ node.right.value
                        return ast.Constant(value=val)

                    except:
                        return node

        return node


def decrypt_xor_strings(source_code):

    try:

        tree = ast.parse(source_code)

        transformer = XORStringDecryptor()

        new_tree = transformer.visit(tree)

        ast.fix_missing_locations(new_tree)

        return ast.unparse(new_tree)

    except Exception as e:

        print("[XORDecryptor] Error:", e)
        return source_code