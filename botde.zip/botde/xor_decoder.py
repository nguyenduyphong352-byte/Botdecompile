import string

PRINTABLE = set(bytes(string.printable, "utf-8"))


def score_text(data):

    score = 0

    for b in data:
        if b in PRINTABLE:
            score += 1

    return score


def xor_decode(data, key):

    return bytes([b ^ key for b in data])


def detect_xor(data):

    best_score = 0
    best_result = None

    for key in range(256):

        decoded = xor_decode(data, key)

        score = score_text(decoded)

        if score > best_score:

            best_score = score
            best_result = decoded

    if best_score > len(data) * 0.6:
        return best_result

    return None