import ast


def beautify_code(source):

    try:

        tree = ast.parse(source)

        formatted = ast.unparse(tree)

        return formatted

    except:
        return source