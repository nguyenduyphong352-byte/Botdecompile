import base64
import binascii
import zlib
import gzip
import bz2
import lzma
import marshal
import re


def decode_layer(layer, data):

    if layer == "base64":
        try:
            return base64.b64decode(data)
        except:
            return data

    elif layer == "base85":
        try:
            return base64.b85decode(data)
        except:
            return data

    elif layer == "hex":
        try:
            return binascii.unhexlify(data.strip())
        except:
            return data

    elif layer == "zlib":
        try:
            return zlib.decompress(data)
        except:
            return data

    elif layer == "gzip":
        try:
            return gzip.decompress(data)
        except:
            return data

    elif layer == "bz2":
        try:
            return bz2.decompress(data)
        except:
            return data

    elif layer == "lzma":
        try:
            return lzma.decompress(data)
        except:
            return data

    elif layer == "marshal":
        try:
            obj = marshal.loads(data)

            # Nếu là code object
            if hasattr(obj, "co_code"):
                import dis
                return dis.Bytecode(obj).dis()

            return str(obj).encode()

        except:
            return data

    elif layer == "exec_wrapper":
        try:

            text = data.decode()

            # tìm nội dung trong exec()
            match = re.search(r'exec\((.+)\)', text)

            if match:
                inner = match.group(1)

                # loại bỏ quote nếu có
                inner = inner.strip().strip('"').strip("'")

                return inner.encode()

            return data

        except:
            return data

    return data